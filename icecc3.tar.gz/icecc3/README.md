# IceWM Control Center 3

Suite de herramientas gráficas para configurar IceWM sin editar archivos a mano.

Basado en el IceWM Control Center original de Vadim A. Khohlov (2002-2004), reconstruido en Python 3 + GTK 4.

## Herramientas incluidas

- **Editor de menús**: edita el menú de aplicaciones visualmente.
- **Editor de barra de herramientas**: añade y ordena lanzadores en la barra superior.
- **Configurador de barra de tareas**: cambia posición, tamaño, doble altura y visibilidad de elementos.
- **Editor de teclas**: atajos de teclado.
- **Cambiador de temas**: explora y aplica temas de IceWM con vista previa.
- **Fondo de escritorio**: selecciona imágenes y aplícalas al instante.
- **Configurador de sonidos**: asocia archivos WAV a eventos de IceWM.
- **Configurador de cursores**: aplica temas XCursor e instala nuevos desde archivos comprimidos.

## Uso rápido

En la carpeta del proyecto:

```bash
./icecc3.py