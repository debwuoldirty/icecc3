#!/usr/bin/env python3
"""
IceWM Control Center 3 (icecc3)
Un lanzador moderno para configurar IceWM.
Licencia: GPL-2.0+
Adaptado del diseño de IceCC 2.9 de Vadim A. Khohlov
"""

import sys
import subprocess
from pathlib import Path

# Obtener el directorio donde se encuentra este script (funciona incluso si es enlace simbólico)
import os
SCRIPT_DIR = Path(os.path.realpath(__file__)).parent

import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk, Gio, GLib

# ------------------------------------------------------------
# Configuración de rutas (estilo moderno de IceWM en Arch)
# ------------------------------------------------------------
ICEWM_CONFIG_DIR = Path.home() / ".icewm"
ICEWM_GLOBAL_DIR = Path("/usr/share/icewm")

CONFIG_FILES = {
    "menu": ICEWM_CONFIG_DIR / "menu",
    "toolbar": ICEWM_CONFIG_DIR / "toolbar",
    "preferences": ICEWM_CONFIG_DIR / "preferences",
    "winoptions": ICEWM_CONFIG_DIR / "winoptions",
    "keys": ICEWM_CONFIG_DIR / "keys",
}

# ------------------------------------------------------------
# Herramientas (las mismas 11, actualizadas)
# ------------------------------------------------------------
TOOLS = [
    {
        "name": "Editor de menús",
        "icon": "accessories-text-editor",
        "command": lambda: run_command([str(SCRIPT_DIR / "icemc.py"), str(CONFIG_FILES["menu"])]),
        "tooltip": "Editar el menú de aplicaciones"
    },
    {
        "name": "Editor de la barra de herramientas",
        "icon": "document-edit",
        "command": lambda: run_command([str(SCRIPT_DIR / "icemc.py"), str(CONFIG_FILES["toolbar"])]),
        "tooltip": "Añadir y ordenar lanzadores en la barra superior"
    },
    {
        "name": "Configurar barra",
        "icon": "preferences-system-windows",
        "command": lambda: run_command(str(SCRIPT_DIR / "icetaskbar.py")),
        "tooltip": "Cambiar posición, tamaño y visibilidad de la barra de tareas"
    },
    {
        "name": "Editar inicio (startup)",
        "icon": "utilities-terminal",
        "command": lambda: run_command(["python3", str(SCRIPT_DIR / "icestartup.py")]),
        "tooltip": "Editar el archivo de inicio de IceWM (~/.icewm/startup)"
    },
    {
        "name": "Editor de teclas",
        "icon": "input-keyboard",
        "command": lambda: run_command(str(SCRIPT_DIR / "iceked.py")),
        "tooltip": "Atajos de teclado"
    },
    {
        "name": "Cambiar tema",
        "icon": "emblem-photos",
        "command": lambda: run_command(str(SCRIPT_DIR / "icets.py")),
        "tooltip": "Explorador de temas visual"
    },
    {
        "name": "Fondo de escritorio",
        "icon": "preferences-desktop-wallpaper",
        "command": lambda: run_command(str(SCRIPT_DIR / "icebgset.py")),
        "tooltip": "Cambiar el fondo de pantalla"
    },
    {
        "name": "Sonido",
        "icon": "audio-speakers",
        "command": lambda: run_command(str(SCRIPT_DIR / "icesndcfg.py")),
        "tooltip": "Ajustes de sonido"
    },
    {
        "name": "Cursores",
        "icon": "input-mouse",
        "command": lambda: run_command(["python3", str(SCRIPT_DIR / "icecurcfg.py")]),
        "tooltip": "Configurar cursores"
    },
]

# ------------------------------------------------------------
# Funciones auxiliares
# ------------------------------------------------------------
_active_window = None  # Referencia global para diálogos

def open_file_with_editor(file_path):
    """Abre un archivo con el editor de texto predeterminado."""
    file_path.parent.mkdir(parents=True, exist_ok=True)
    if not file_path.exists():
        file_path.touch()
    uri = GLib.filename_to_uri(str(file_path), None)
    Gio.AppInfo.launch_default_for_uri(uri, None)

def run_command(command):
    """Ejecuta un comando en segundo plano, acepta cadena o lista."""
    if isinstance(command, str):
        cmd_list = command.split()
    else:
        cmd_list = command
    try:
        subprocess.Popen(cmd_list, start_new_session=True)
    except FileNotFoundError:
        show_error(f"No se encontró el comando '{cmd_list[0]}'.\nAsegúrate de tenerlo instalado.")

def show_error(msg):
    global _active_window
    dialog = Gtk.MessageDialog(
        transient_for=_active_window,
        modal=True,
        message_type=Gtk.MessageType.ERROR,
        buttons=Gtk.ButtonsType.OK,
        text=msg
    )
    dialog.present()
    dialog.connect("response", lambda d, r: d.close())

# ------------------------------------------------------------
# Ventana principal
# ------------------------------------------------------------
class IceCCWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        global _active_window
        _active_window = self

        self.set_title("IceWM Control Center")
        self.set_default_size(350, 500)

        # Cabecera
        header = Gtk.HeaderBar()
        header.set_show_title_buttons(True)
        header.set_title_widget(Gtk.Label(label="IceWM Control Center"))
        self.set_titlebar(header)

        # Caja vertical principal
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.set_child(vbox)

        # Contenedor para los botones (usamos Box en lugar de ListBox)
        tool_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        vbox.append(tool_box)

        for tool in TOOLS:
            # Crear un botón para cada herramienta
            btn = Gtk.Button()
            btn.set_tooltip_text(tool["tooltip"])
            btn.add_css_class("flat")  # estilo plano, parece una fila

            # Conectar la acción al hacer clic
            btn.connect("clicked", lambda widget, cmd=tool["command"]: cmd())

            # Contenido horizontal dentro del botón
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            box.set_margin_top(6)
            box.set_margin_bottom(6)
            box.set_margin_start(10)
            box.set_margin_end(10)

            # Icono
            icon = Gtk.Image.new_from_icon_name(tool["icon"])
            icon.set_pixel_size(24)
            box.append(icon)

            # Etiqueta con el nombre de la herramienta
            label = Gtk.Label(label=tool["name"], xalign=0)
            box.append(label)

            btn.set_child(box)
            tool_box.append(btn)

        # Botón Salir al final
        btn_exit = Gtk.Button.new_with_label("Salir")
        vbox.append(btn_exit)
        btn_exit.connect("clicked", lambda _: self.close())

# ------------------------------------------------------------
# Aplicación GTK
# ------------------------------------------------------------
class IceCCApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.icecc.controlcenter")
        self.connect("activate", self.on_activate)

    def on_activate(self, app):
        win = IceCCWindow(application=app)
        win.present()

# ------------------------------------------------------------
# Punto de entrada
# ------------------------------------------------------------
if __name__ == "__main__":
    app = IceCCApp()
    app.run(sys.argv)